#!/bin/bash
hour=`date +%F_%T`
clamscan --recursive --infected --exclude=Backup --exclude=Virt --exclude=Temp/ISO --log=/var/log/clamav/daily/avscan-"$hour".log --move=/root/.isolation /mnt/Local/Container-C
find /root/.isolation -type f -mtime +7 -delete 
find /var/log/clamav/daily -name "*.log" -type f -mtime +2 -delete